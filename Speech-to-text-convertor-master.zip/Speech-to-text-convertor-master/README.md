# Speech-to-text-convertor
This is a Speech to text converter app that recognises the speech and converts them to text in English. This is done using JavaScript and it uses webkitSpeechRecognitionEvent
